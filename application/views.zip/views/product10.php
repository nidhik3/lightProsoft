
<section id="services" class="services lightblue  pt-120 pb-60">
        <div class="container">
        <div class="row text-center pb-4">
            <h3 class="tm-gold-text tm-form-title"><span class="gradient-text">KIOSK SOLUTIONS</span></h3>
        </div> 
       
            <div class="row" >
                <div class="col-md-6">
                <p>
                PROSOFT provides the different kind of KIOSK system which helps customer to perform.</p>
                    <p><span style="font-weight: 800;font-size: 1.8em; line-height: 1"></span> Book Appointments</p>
                    <p><span style="font-weight: 800;font-size: 1.8em; line-height: 1"></span> Payments Options</p>
                    <p><span style="font-weight: 800;font-size: 1.8em; line-height: 1"></span> Patient Registrations</p>
                    <p><span style="font-weight: 800;font-size: 1.8em; line-height: 1"></span> Print Invoice / Receipt</p>
                    <p><span style="font-weight: 800;font-size: 1.8em; line-height: 1"></span> Print Lab Reports</p>
                    <p><span style="font-weight: 800;font-size: 1.8em; line-height: 1"></span> Print Radiology Reports</p>
                </div>
                <div class="col-md-6" style="margin:auto;justify-content: center;display: flex;">
                    <img src="assets/image/ris.jpg" alt="" width="100%" style="border-radius: 20px;">
                </div>
            </div>

        </div>
        <br />

    </section>



    <script>
        $(document).ready(function() {
            $('a[href$="#"]').addClass(" active");
        })
    </script>